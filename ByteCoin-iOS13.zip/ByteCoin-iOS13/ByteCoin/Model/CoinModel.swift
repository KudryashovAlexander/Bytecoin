//
//  CoinModel.swift
//  ByteCoin
//
//  Created by Александр Кудряшов on 22/08/2020.
//  Copyright © 2020 The App Brewery. All rights reserved.
//

import Foundation
struct CoinModel {
    let time: String
    let coin: String
    let money: String
    let rate : Double
    
    var rateString: String {
        return String(format:"%.1f", rate)
    }
    
}
